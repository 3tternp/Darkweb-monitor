# backend/main.py
from fastapi import FastAPI
from app.api import auth, monitor, crawler, rules
from app.core.config import SECRET_KEY

app = FastAPI()

# Include routers
app.include_router(auth.router)
app.include_router(monitor.router)
app.include_router(crawler.router)
app.include_router(rules.router)
