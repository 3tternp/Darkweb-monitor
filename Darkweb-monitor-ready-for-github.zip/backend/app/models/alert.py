from sqlalchemy import Column, Integer, String, DateTime
from app.db import Base  # Assuming you set up a Base class for SQLAlchemy models
import datetime

class Alert(Base):
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    keyword = Column(String, index=True)
    source = Column(String)
    date = Column(DateTime, default=datetime.datetime.utcnow)

