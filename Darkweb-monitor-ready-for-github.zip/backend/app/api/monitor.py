from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app import models, schemas
from app.db import get_db
from app.core.security import get_current_user

router = APIRouter()

@router.get("/monitor/alerts", response_model=list[schemas.Alert])
def get_alerts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    alerts = db.query(models.Alert).all()
    return alerts

@router.get("/monitor/stats")
def get_stats(db: Session = Depends(get_db), user=Depends(get_current_user)):
    total_alerts = db.query(models.Alert).count()
    total_keywords = db.query(models.Keyword).count()
    new_alerts = db.query(models.Alert).filter(models.Alert.date >= datetime.datetime.utcnow() - timedelta(days=1)).count()
    return {"totalAlerts": total_alerts, "keywords": total_keywords, "newAlerts": new_alerts}

@router.get("/monitor/keywords", response_model=list[schemas.Keyword])
def get_keywords(db: Session = Depends(get_db), user=Depends(get_current_user)):
    keywords = db.query(models.Keyword).all()
    return keywords

@router.post("/monitor/keywords", response_model=schemas.Keyword)
def add_keyword(keyword: schemas.KeywordCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    db_keyword = models.Keyword(keyword=keyword.keyword)
    db.add(db_keyword)
    db.commit()
    db.refresh(db_keyword)
    return db_keyword

@router.delete("/monitor/keywords/{keyword_id}")
def delete_keyword(keyword_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    db_keyword = db.query(models.Keyword).filter(models.Keyword.id == keyword_id).first()
    if db_keyword is None:
        raise HTTPException(status_code=404, detail="Keyword not found")
    db.delete(db_keyword)
    db.commit()
    return {"detail": "Keyword deleted"}

