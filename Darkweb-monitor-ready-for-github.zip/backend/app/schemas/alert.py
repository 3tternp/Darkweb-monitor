from pydantic import BaseModel
from datetime import datetime

class AlertBase(BaseModel):
    keyword: str
    source: str

class AlertCreate(AlertBase):
    pass

class Alert(AlertBase):
    id: int
    date: datetime

    class Config:
        orm_mode = True

