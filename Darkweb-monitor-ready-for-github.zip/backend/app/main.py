from fastapi import FastAPI
from .api import auth, monitor

app = FastAPI()

# Include routers
app.include_router(auth.router)
app.include_router(monitor.router)

# Optional: Add CORS, Middleware, etc. if needed later

