# backend/api/crawler.py
from fastapi import APIRouter
from app.services.crawler_service import start_crawler, stop_crawler

router = APIRouter()

@router.post("/start_crawler")
async def start():
    result = await start_crawler()  # Start the dark web crawler
    return {"message": "Crawler started", "result": result}

@router.post("/stop_crawler")
async def stop():
    result = await stop_crawler()  # Stop the dark web crawler
    return {"message": "Crawler stopped", "result": result}
