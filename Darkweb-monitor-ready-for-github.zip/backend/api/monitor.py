# backend/api/monitor.py
from fastapi import APIRouter, Depends
from app.services.alert_service import get_alerts, get_stats

router = APIRouter()

@router.get("/alerts")
async def fetch_alerts():
    alerts = await get_alerts()  # Fetch from database or other service
    return alerts

@router.get("/stats")
async def fetch_stats():
    stats = await get_stats()  # Calculate stats like total alerts, new alerts, etc.
    return stats
