# backend/api/rules.py
from fastapi import APIRouter
from app.services.alert_service import create_rule, delete_rule

router = APIRouter()

@router.post("/rules")
async def add_rule(rule_data: dict):
    new_rule = await create_rule(rule_data)
    return new_rule

@router.delete("/rules/{rule_id}")
async def remove_rule(rule_id: int):
    result = await delete_rule(rule_id)
    return {"message": "Rule deleted", "result": result}
