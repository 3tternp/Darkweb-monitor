import { useEffect, useState } from "react";
import API from "../services/api";
import Sidebar from "../components/Sidebar";
import DashboardCard from "../components/DashboardCard";
import AlertTable from "../components/AlertTable";

export default function Dashboard() {
  const [alerts, setAlerts] = useState([]);
  const [stats, setStats] = useState({ totalAlerts: 0, keywords: 0, newAlerts: 0 });

  useEffect(() => {
    const fetchData = async () => {
      const alertRes = await API.get("/monitor/alerts");
      const statsRes = await API.get("/monitor/stats");
      setAlerts(alertRes.data);
      setStats(statsRes.data);
    };
    fetchData();
  }, []);

  return (
    <div className="flex">
      <Sidebar />
      <main className="ml-64 p-6 w-full bg-gray-100 min-h-screen">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
        <div className="flex gap-4 flex-wrap mb-6">
          <DashboardCard title="Total Alerts" count={stats.totalAlerts} />
          <DashboardCard title="Keywords Monitored" count={stats.keywords} />
          <DashboardCard title="New in 24h" count={stats.newAlerts} />
        </div>
        <AlertTable alerts={alerts} />
      </main>
    </div>
  );
}

