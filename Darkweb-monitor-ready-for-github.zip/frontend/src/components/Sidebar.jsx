import { FaShieldAlt, FaBell, FaSearch } from "react-icons/fa";

export default function Sidebar() {
  return (
    <div className="bg-gray-900 text-white h-screen w-64 p-6 fixed">
      <h1 className="text-2xl font-bold mb-10">DarkWeb Monitor</h1>
      <nav className="space-y-4">
        <div className="flex items-center gap-2 hover:text-blue-400 cursor-pointer"><FaShieldAlt /> Dashboard</div>
        <div className="flex items-center gap-2 hover:text-blue-400 cursor-pointer"><FaSearch /> Keywords</div>
        <div className="flex items-center gap-2 hover:text-blue-400 cursor-pointer"><FaBell /> Alerts</div>
      </nav>
    </div>
  );
}
