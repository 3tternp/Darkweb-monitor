export default function AlertTable({ alerts }) {
  return (
    <div className="bg-white p-4 rounded-xl shadow mt-6">
      <h3 className="text-lg font-semibold mb-4">Recent Alerts</h3>
      <table className="w-full text-sm text-left text-gray-600">
        <thead className="text-xs text-gray-500 uppercase bg-gray-100">
          <tr>
            <th className="px-4 py-2">Keyword</th>
            <th className="px-4 py-2">Source</th>
            <th className="px-4 py-2">Date Found</th>
          </tr>
        </thead>
        <tbody>
          {alerts.map((alert, index) => (
            <tr key={index} className="border-t">
              <td className="px-4 py-2">{alert.keyword}</td>
              <td className="px-4 py-2">{alert.source}</td>
              <td className="px-4 py-2">{alert.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
