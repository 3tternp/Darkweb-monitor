export default function DashboardCard({ title, count }) {
  return (
    <div className="bg-white shadow-lg rounded-2xl p-6 w-full md:w-1/3">
      <h2 className="text-gray-600 text-sm">{title}</h2>
      <p className="text-3xl font-semibold text-blue-700">{count}</p>
    </div>
  );
}
